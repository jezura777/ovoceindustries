## Credits

Jezura777 - Programming, Art design
\_ATUK\_ - Testing

Made with (allegro5 game programming library)[liballeg.org] in C programming language.


## How to compile

Run `make OS={your os}` and replace {your os} with win on windows or linux on unix based os'es.

Make sure you have installed make, mingw on windows or gcc on linux and allegro5 libs for C.